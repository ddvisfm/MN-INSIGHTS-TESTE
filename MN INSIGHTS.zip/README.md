# MN Insights

O **MN Insights** conecta métricas de mídia ao feedback comercial dos clientes. A versão 0.4 mantém o sistema sem dados fictícios, inicia com a base real de clientes ativos da agência e preserva a separação entre a área interna da MN e os links públicos de relatório, além da exportação profissional em `.xlsx`.

## Requisitos

- Node.js **22.13 ou superior**
- npm 10+

## Instalação e execução

```bash
npm install
npm run dev
```

Abra:

```text
http://localhost:3000
```

### Primeiro acesso

Na primeira execução, como ainda não existe usuário interno, o sistema redireciona para:

```text
/setup-admin
```

Crie o nome do usuário da equipe, o e-mail administrativo e uma senha com pelo menos 12 caracteres, contendo letra e número. **Nenhuma senha padrão é incluída no projeto.** Depois disso, o login interno usa e-mail + senha e a área administrativa passa a exigir sessão autenticada. Bancos anteriores que já possuam o primeiro administrador recebem a coluna de e-mail de forma aditiva; no primeiro login válido, o e-mail informado é associado à credencial legada.

## Rotas

### Internas — exigem sessão

```text
/dashboard
/clientes
/clientes/novo
/clientes/:codigoMN
/relatorios
/relatorios/novo
/relatorios/:id
/teses
```

### Externas

```text
/login
/setup-admin        # somente antes da configuração inicial
/r/:token           # link público de um relatório específico
```

O link público não cria sessão administrativa e não concede acesso a dashboard, clientes, exportações ou APIs internas.

## Segurança implementada

- sessão administrativa com token aleatório armazenado no banco apenas como hash;
- cookie `HttpOnly`, `SameSite=Strict` e `Secure` automaticamente em HTTPS;
- expiração automática de sessão;
- proteção CSRF em operações internas que alteram dados;
- validação de origem em requisições sensíveis;
- autorização obrigatória no backend para rotas e APIs internas;
- links públicos com tokens aleatórios não sequenciais;
- isolamento: a API pública só acessa o relatório correspondente ao token;
- prevenção de resposta duplicada no servidor;
- rate limiting para login, envio público e exportações;
- CSP, `X-Content-Type-Options`, `Referrer-Policy`, `X-Frame-Options`, `Permissions-Policy`, COOP/CORP e HSTS quando HTTPS;
- consultas SQL parametrizadas;
- limite de tamanho de payload;
- erros internos não são enviados com stack trace ao navegador;
- auditoria de login, criação de cliente, criação/envio de relatório e exportações;
- proteção contra formula injection nas planilhas XLSX.

Nenhum sistema pode ser garantido como impossível de invadir. Estas medidas reduzem significativamente a superfície de ataque e aplicam defesa em profundidade para o estágio atual do produto.

## Navegação por cliente

Na área interna, os nomes de clientes em tabelas, pendências, relatórios e cards são links para o hub daquele cliente. O redirecionamento usa o código estável `MNxxx`, não o nome exibido.

A identificação visual dos clientes usa:

```text
MN
023
```

O número é extraído do código comercial real cadastrado, nunca da posição na lista.

## Campos monetários

Os campos de investimento e CPC aceitam entrada brasileira, por exemplo:

```text
250
2500
2500,5
R$ 2.500,00
```

Ao sair do campo, a interface normaliza a apresentação para duas casas decimais. Internamente, os valores continuam armazenados como centavos inteiros para preservar cálculos.

## Exportação XLSX

### Um relatório

Abra `/relatorios/:id` e use **Exportar relatório**.

### Vários relatórios

Na Central de Relatórios, aplique filtros de cliente/status se desejar e use **Exportar planilha**. No painel individual do cliente também existe **Exportar histórico**.

A planilha contém, conforme os dados realmente existentes:

- identificação do cliente e código MN;
- período e status visual (Respondido, Aguardando ou Atrasado);
- teses;
- investimento, leads, CPL e CPC;
- contratos e custo por contrato quando calculável;
- atendimento e quantidade informada (quando aplicável; “Todos” não grava quantidade redundante);
- qualidade dos leads;
- situação e quantidade de contratos;
- quantidade de leads em negociação, quando essa situação for selecionada;
- problemas selecionados;
- campo “Outro”;
- observação da campanha;
- feedback para a MN;
- data/hora da resposta.

Campos que não existem no modelo atual, como CTR ou CPM, **não são inventados**.

O arquivo possui abas **Resumo**, **Métricas** e **Respostas**, cabeçalhos com a identidade visual do MN Insights, filtros, congelamento de cabeçalho, larguras de coluna e formatos de moeda.

O sistema registra cada exportação em **Relatórios → Exportações recentes**, incluindo escopo, cliente, arquivo, quantidade de registros, responsável e data.

## Banco de dados

Por padrão:

```text
data/mn-insights.db
```

O banco é criado/migrado automaticamente. A carga inicial adiciona de forma idempotente os clientes ativos da base da agência e suas teses, sem criar relatórios ou métricas. Clientes e relatórios já existentes são preservados.

Para recriar o banco local e carregar novamente a base inicial da agência:

```bash
npm run db:reset
npm run dev
```

## Variáveis de ambiente

Veja `.env.example`:

```env
PORT=3000
HOST=127.0.0.1
DATABASE_PATH=./data/mn-insights.db
TRUST_PROXY=0
```

Em um deploy atrás de proxy reverso confiável, configure `TRUST_PROXY=1` para que o rate limiting utilize corretamente o IP encaminhado.

## Validação

```bash
npm run lint
npm run typecheck
npm test
npm run build
```

Ou tudo de uma vez:

```bash
npm run check
```

Os testes cobrem as regras anteriores do MN Insights e também autenticação/sessão, revogação de sessão, acesso público aos links de relatório, comportamento de “Todos”, quantidade em negociação e geração de XLSX.

## Estrutura principal

```text
src/
├── agency-base.ts   # carga inicial idempotente de clientes e teses da agência
├── auth.ts          # credenciais, hash de senha e sessões
├── client/app.ts    # interface e navegação
├── db.ts            # persistência e regras de negócio
├── server.ts        # rotas, autorização, headers, rate limiting e APIs
├── xlsx.ts          # geração XLSX sem dependência externa de runtime
└── shared/types.ts
```

## Build de produção

```bash
npm run build
npm start
```
